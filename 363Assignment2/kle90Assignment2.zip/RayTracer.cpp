/*==================================================================================
* COSC 363  Computer Graphics (2021)
* Department of Computer Science and Software Engineering, University of Canterbury.
*
* A basic ray tracer
* See Lab07.pdf  for details.
*===================================================================================
*/
#include "TextureBMP.h"
#include <iostream>
#include <cmath>
#include <vector>
#include <glm/glm.hpp>
#include "Sphere.h"
#include "SceneObject.h"
#include "Ray.h"
#include "Plane.h"
#include <GL/freeglut.h>
using namespace std;

const float WIDTH = 20.0;
const float HEIGHT = 20.0;
const float EDIST = 40.0;
const int NUMDIV = 500;
const int MAX_STEPS = 5;
const float XMIN = -WIDTH * 0.5;
const float XMAX =  WIDTH * 0.5;
const float YMIN = -HEIGHT * 0.5;
const float YMAX =  HEIGHT * 0.5;

TextureBMP texture;
vector<SceneObject*> sceneObjects;


//---The most important function in a ray tracer! ----------------------------------
//   Computes the colour value obtained by tracing a ray and finding its
//     closest point of intersection with objects in the scene.
//----------------------------------------------------------------------------------
glm::vec3 trace(Ray ray, int step)
{
    glm::vec3 backgroundCol(0);                     //Background colour = (0,0,0)
    glm::vec3 lightPos(10, 40, -3);                 //Light's position
    glm::vec3 color(0);
    SceneObject* obj;

    ray.closestPt(sceneObjects);                    //Compare the ray with all objects in the scene
    if(ray.index == -1) return backgroundCol;       //no intersection
    obj = sceneObjects[ray.index];                  //object on which the closest point of intersection is found

    if (ray.index == 4)
    {
        //Stripe pattern
        int stripeWidth = 5;
        int iz = (ray.hit.z) / stripeWidth;
        int ix = (ray.hit.x) / stripeWidth;
        int k = (iz + ix) % 2; //2 colors
        if (k == 0) color = glm::vec3(0, 1, 0);
        else color = glm::vec3(1, 1, 0.5);
        obj->setColor(color);


        //Add code for texture mapping here
        float a1 = -15;
        float a2 = 5;
        float b1 = -60;
        float b2 = -90;
        float texcoords = (ray.hit.x - (a1)) / (a2 - a1);
        float texcoordt = (ray.hit.z - (b1)) / (b2 - b1);
        if(texcoords > 0 && texcoords < 1 &&
            texcoordt > 0 && texcoordt < 1)
        {
            color=texture.getColorAt(texcoords, texcoordt);
            obj->setColor(color);
        }
    }



    color = obj->lighting(lightPos, -ray.dir, ray.hit);                        //Object's colour
    glm::vec3 lightVec = lightPos - ray.hit;
    Ray shadowRay(ray.hit, lightVec);
    shadowRay.closestPt(sceneObjects);

    float lightDist = glm::length(lightVec);

    // nested if is a condiotoin to get object color in shadow.
    if (shadowRay.index > -1 && shadowRay.dist < lightDist) {
        SceneObject* obj_shadow;
        obj_shadow = sceneObjects[shadowRay.index];
        if (obj_shadow->isTransparent() && step < MAX_STEPS){
            float transRho = obj->getTransparencyCoeff();
            color = color * 0.6f + 0.3f * obj_shadow->getColor();
        }
        else {color = 0.1f * obj->getColor();} //0.2 = ambient scale factor
    }

    if (obj->isReflective() && step < MAX_STEPS)
    {
        float rho = obj->getReflectionCoeff();
        glm::vec3 normalVec = obj->normal(ray.hit);
        glm::vec3 reflectedDir = glm::reflect(ray.dir, normalVec);
        Ray reflectedRay(ray.hit, reflectedDir);
        glm::vec3 reflectedColor = trace(reflectedRay, step + 1);
        color = color + (rho * reflectedColor);
    }

    // For transparency
    if (obj->isTransparent() && step < MAX_STEPS){
        float transRho = obj->getTransparencyCoeff();
        Ray transparentRay1 = Ray(ray.hit, ray.dir);
        transparentRay1.closestPt(sceneObjects);
        Ray transparentRay2 = Ray(transparentRay1.hit, transparentRay1.dir);
        glm::vec3 transparentColor = trace(transparentRay2, step + 1);
        color = color + (transRho * transparentColor);
    }

    return color;
}

//---The main display module -----------------------------------------------------------
// In a ray tracing application, it just displays the ray traced image by drawing
// each cell as a quad.
//---------------------------------------------------------------------------------------
void display()
{
    float xp, yp;  //grid point
    float cellX = (XMAX-XMIN)/NUMDIV;  //cell width
    float cellY = (YMAX-YMIN)/NUMDIV;  //cell height
    glm::vec3 eye(0., 0., 0.);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glBegin(GL_QUADS);  //Each cell is a tiny quad.

    for(int i = 0; i < NUMDIV; i++) //Scan every cell of the image plane
    {
        xp = XMIN + i*cellX;
        for(int j = 0; j < NUMDIV; j++)
        {
            yp = YMIN + j*cellY;

            glm::vec3 dir(xp+0.5*cellX, yp+0.5*cellY, -EDIST);  //direction of the primary ray

            Ray ray = Ray(eye, dir);

            glm::vec3 col = trace (ray, 1); //Trace the primary ray and get the colour value
            glColor3f(col.r, col.g, col.b);
            glVertex2f(xp, yp);             //Draw each cell with its color value
            glVertex2f(xp+cellX, yp);
            glVertex2f(xp+cellX, yp+cellY);
            glVertex2f(xp, yp+cellY);
        }
    }

    glEnd();
    glFlush();
}



//---This function initializes the scene -------------------------------------------
//   Specifically, it creates scene objects (spheres, planes, cones, cylinders etc)
//     and add them to the list of scene objects.
//   It also initializes the OpenGL orthographc projection matrix for drawing the
//     the ray traced image.
//----------------------------------------------------------------------------------
void initialize()
{
    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(XMIN, XMAX, YMIN, YMAX);
    texture = TextureBMP("Butterfly.bmp");
    glClearColor(0, 0, 0, 1);

    Sphere *sphere1 = new Sphere(glm::vec3(-5.0, 0.0, -90.0), 15.0);
    sphere1->setColor(glm::vec3(0, 0, 1));   //Set colour to blue
    sphere1->setReflectivity(true, 1);
    sceneObjects.push_back(sphere1);         //Add sphere to scene objects

    Sphere *sphere2 = new Sphere(glm::vec3(5.0, -10.0, -70.0), 5.0);
    sphere2->setColor(glm::vec3(0, 1, 0));   //Set colour to green
    sphere2->setTransparency(true, 0.7);     //Set transparency
    //~ sphere2->setSpecularity(false);      //remove shininess
    sceneObjects.push_back(sphere2);         //Add sphere to scene objects

    Sphere *sphere3 = new Sphere(glm::vec3(4.0, 6.0, -70.0), 3.5);
    sphere3->setColor(glm::vec3(1, 0, 0));   //Set colour to red
    //~ sphere3->setShininess(5);                //set shininess
    sceneObjects.push_back(sphere3);         //Add sphere to scene objects

    Sphere *sphere4 = new Sphere(glm::vec3(9.0, 10.0, -60.0), 3.5);
    sphere4->setColor(glm::vec3(0, 1, 1));   //Set colour to cyan
    sceneObjects.push_back(sphere4);         //Add sphere to scene objects

    Plane *plane = new Plane (glm::vec3(-30., -15, 0), //Point A
                             glm::vec3(30., -15, 0), //Point B
                             glm::vec3(30., -15, -200), //Point C
                             glm::vec3(-30., -15, -200)); //Point D
    plane->setColor(glm::vec3(0.8, 0.8, 0));
    sceneObjects.push_back(plane);

    Plane *backPlane = new Plane (glm::vec3(30., 100, -200),
                                glm::vec3(-30., 100, -200),
                                glm::vec3(-30., -15, -200),
                                glm::vec3(30., -15, -200));
    backPlane->setSpecularity(false);


    backPlane->setColor(glm::vec3(0, 1, 0));
    sceneObjects.push_back(backPlane);

    Plane *rightPlane = new Plane (glm::vec3(30., -15, -200), //Point C
                                glm::vec3(30., -15, 0), //Point B
                                glm::vec3(30., 100, 0),
                                glm::vec3(30., 100, -200));


    rightPlane->setColor(glm::vec3(1, 0, 0));
    sceneObjects.push_back(rightPlane);

    Plane *leftPlane = new Plane (glm::vec3(-30., -15, 0), //Point C
                                glm::vec3(-30., -15, -200), //Point D
                                glm::vec3(-30., 100, -200),
                                glm::vec3(-30., 100, 0));


    leftPlane->setColor(glm::vec3(0, 1, 1));
    sceneObjects.push_back(leftPlane);



    Plane *frontPlane = new Plane (glm::vec3(30., 100, 0),
                                glm::vec3(-30., -15, 0),
                                glm::vec3(-30., 100, 0),
                                glm::vec3(30., -15, 0));


    frontPlane->setColor(glm::vec3(1, 1, 0));
    //sceneObjects.push_back(frontPlane);


    //~ Plane *sq = new Plane (glm::vec3(-5., 0, -25), //Point A
                           //~ glm::vec3(5., 5, -20), //Point B
                           //~ glm::vec3(25., -10, -150), //Point C
                           //~ glm::vec3(0., 5, -152)); //Point D
    //~ sq->setColor(glm::vec3(0.3, 0.8, 0.2));
    //~ plane->setSpecularity(false); //remove shininess
    //~ sceneObjects.push_back(sq);
}


int main(int argc, char *argv[]) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB );
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(20, 20);
    glutCreateWindow("Raytracing");

    glutDisplayFunc(display);
    initialize();

    glutMainLoop();
    return 0;
}
